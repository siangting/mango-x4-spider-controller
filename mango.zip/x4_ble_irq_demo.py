from mango import MangoBLE
import time

def ble_read_handler():
    print(ble.read().decode().strip())

ble = MangoBLE(on_rx=ble_read_handler, name="MANGO", rxbuf=100)

try:
    while True:
        ble.write("hello\n")
        time.sleep(1)
except KeyboardInterrupt:
    ble.close()
    print('--- close ---')