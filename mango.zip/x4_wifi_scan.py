import network
import time
import machine

class WiFiTester:
    def __init__(self, country='TW'):
        # 初始化 CYW43 晶片
        # 注意：在某些 RP2350 韌體中，可能需要指定特定的電源管理模式
        self.wlan = network.WLAN(network.STA_IF)
        self.wlan.active(True)
        
    def scan(self):
        """掃描週邊熱點並印出"""
        print("--- 正在掃描 WiFi 熱點 ---")
        networks = self.wlan.scan()
        # scan 回傳格式: (ssid, bssid, channel, RSSI, security, hidden)
        for net in networks:
            ssid = net[0].decode('utf-8')
            rssi = net[3]
            print(f"SSID: {ssid:20} | 信號強度: {rssi} dBm")
        return networks

    def connect(self, ssid, password, timeout=10):
        """連接至指定熱點"""
        if self.wlan.isconnected():
            print("WiFi 已經連接。")
            return True

        print(f"正在連接至 {ssid}...")
        self.wlan.connect(ssid, password)

        # 等待連接
        start_time = time.time()
        while not self.wlan.isconnected() and (time.time() - start_time) < timeout:
            # 閃爍板載燈 (如果有定義) 或簡單等待
            print(".", end="")
            time.sleep(1)

        if self.wlan.isconnected():
            print("\n連接成功！")
            config = self.wlan.ifconfig()
            print(f"IP 地址: {config[0]}")
            print(f"子網路遮罩: {config[1]}")
            print(f"網關: {config[2]}")
            print(f"DNS: {config[3]}")
            return True
        else:
            status = self.wlan.status()
            print(f"\n連接失敗。狀態碼: {status}")
            self._diagnose_status(status)
            return False

    def _diagnose_status(self, status):
        """診斷錯誤原因"""
        diag = {
            network.STAT_IDLE: "閒置狀態",
            network.STAT_CONNECTING: "連接中",
            network.STAT_WRONG_PASSWORD: "密碼錯誤",
            network.STAT_NO_AP_FOUND: "找不到該 SSID",
            network.STAT_CONNECT_FAIL: "連接失敗",
            network.STAT_GOT_IP: "已取得 IP"
        }
        print(f"診斷建議: {diag.get(status, '未知錯誤')}")

    def disconnect(self):
        self.wlan.disconnect()
        self.wlan.active(False)
        print("WiFi 已關閉。")

# --- 執行測試 ---
if __name__ == "__main__":
    test = WiFiTester(country='TW')
    
    # 1. 測試硬體掃描功能
    test.scan()
    
    # 2. 測試連接功能 (請替換為你的 WiFi 資訊)
    SSID = "GINA-F1"
    PASSWORD = "0905732777"
    
    if test.connect(SSID, PASSWORD):
        # 測試網路是否真的通 (Ping 測試或簡單 HTTP)
        import urequests
        try:
            print("正在測試網際網路連接...")
            r = urequests.get("http://google.com")
            print(f"回應狀態碼: {r.status_code}")
            r.close()
        except Exception as e:
            print(f"網路測試失敗: {e}")
    
    # 如果只是測試，測試完後可選擇斷開
    time.sleep(3)
    test.disconnect()