from machine import Pin, SoftSPI, PWM
from mango import st7789
from fonts import vga2_8x8 as font1
from fonts import vga2_8x16 as font2
from fonts import vga2_bold_16x16 as font3
from fonts import vga2_bold_16x32 as font4
import time

# --- 1. 定義 SoftSPI ---
# 根據你的硬體：SDA(MOSI)=26, SCL(SCK)=27
# MISO 對於 ST7789 通常不需要，隨便找個沒用的腳位或不定義
soft_spi = SoftSPI(
    baudrate=40_000_000, 
    polarity=1, 
    phase=1, 
    sck=Pin(27), 
    mosi=Pin(26), 
    miso=Pin(25) # 雖然不用，但 SoftSPI 通常需要定義
)

# --- 2. 控制腳位設定 ---
cs = Pin(33, Pin.OUT)
dc = Pin(34, Pin.OUT)
rst = Pin(35, Pin.OUT)
bl = Pin(32, Pin.OUT)
bl.value(1) # 開啟背光

# --- 3. 建立顯示物件 ---
# 請注意：SoftSPI 的傳輸效率較低，若畫面有位移，可調低 baudrate
display = st7789.ST7789(
    soft_spi, 
    240, 
    240, 
    reset=rst, 
    dc=dc, 
    cs=cs, 
    rotation=0
)

def test_screen():
    print("啟動 SoftSPI 螢幕測試...")
    try:
        # 測試色彩填充
        colors = [st7789.RED, st7789.GREEN, st7789.BLUE, st7789.BLACK]
        for color in colors:
            display.fill(color)
            time.sleep_ms(100)
        
        # 畫個方塊驗證解析度
        display.rect(60, 60, 120, 120, st7789.WHITE)
        # 文字
        
        print("測試完畢，螢幕應顯示藍底白方塊")
    except Exception as e:
        print(f"螢幕顯示失敗: {e}")
        
def test_draw_image():
    import mango_logo as logo
    SPEED_X = 3
    SPEED_Y = 2
    TICKS = 100
    width, height = display.width, display.height
    col, row = width // 2 - logo.WIDTH // 2, height // 2 - logo.HEIGHT // 2
    xd, yd = SPEED_X, SPEED_Y
    last_col, old_row = col, row
    while True:
        last = time.ticks_ms()
        display.fill_rect(last_col, old_row, logo.WIDTH, logo.HEIGHT, 0)
        display.bitmap(logo, col, row)
        last_col, old_row = col, row
        col, row = col + xd, row + yd
        xd = -xd if col <= 0 or col >= width - logo.WIDTH else xd
        yd = -yd if row <= 0 or row >= height - logo.HEIGHT else yd

        if time.ticks_ms() - last < TICKS:
            time.sleep_ms(TICKS - (time.ticks_ms() - last))
            
def test_image_text():
    import mango_logo as logo
    print('test draw image')
    display.fill_rect(0, 0, logo.WIDTH, logo.HEIGHT, 0)
    display.bitmap(logo, 0, 0)
    print('test draw text')
    char = 'MANGO X4'
    display.text(font4, char, 30, 250, st7789.GREEN, st7789.BLACK)

test_image_text()