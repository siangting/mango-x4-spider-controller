from mango import WS2812B
import time

rgb = WS2812B(pin=45, leds=6, channel=4)

for color in WS2812B.COLORS:
    rgb.show_all(color)
    time.sleep(1)
rgb.close()