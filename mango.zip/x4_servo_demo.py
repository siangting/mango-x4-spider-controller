from mango import DCMotor
from mango import SerialServo
from mango import utils
import time


# test motor
m1 = DCMotor(0, 1)
m2 = DCMotor(2, 3)
m3 = DCMotor(4, 5)
m4 = DCMotor(6, 7)
speed_value = 100 # -100~0~100, 負值為反轉
m1.speed(speed_value)  
m2.speed(speed_value)
m3.speed(speed_value)
m4.speed(speed_value)
time.sleep(3)
m1.stop()
m2.stop()
m3.stop()
m4.stop()


# test servo
servo = SerialServo(uart_id=1, tx_pin=8, rx_pin=9)
servo.move_servo_immediate(servo_id=254, angle=90, time_ms=100)
time.sleep(0.5)
servo.move_servo_immediate(servo_id=254, angle=180, time_ms=100)
time.sleep(0.5)
servo.move_servo_immediate(servo_id=254, angle=0, time_ms=100)
