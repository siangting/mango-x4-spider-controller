from mango import Buzzer


buzzer = Buzzer(pin='BUZZER')    

# 參數: freq, duty
buzzer.play(500, 5000)
sleep(2)
buzzer.stop()

for i in range(5):
    # 參數: freq, duty, duration(sleep)
    buzzer.buzz(262, 5000, 0.5)
    buzzer.buzz(392, 5000, 0.5)
sleep(2)
buzzer.stop()

