from machine import Pin, SoftI2C
from mango import OLED
from mango.icons import mango_logo as icon
import time
    
# 使用 OLED 專用接口: SCL=26, SDA=27
# 使用 TFT 專用接口: SCL=27, SDA=26
i2c = SoftI2C(scl=Pin(27), sda=Pin(26), freq=100000)
oled = OLED(i2c)
oled.power_on()
oled.show_image_data(icon.bitmap_data, 1)    
time.sleep(3)
oled.clear()
oled.power_off()
