from mango import Button
import time


def demo(event):
    event_name = "DOWN" if event is Button.EVENT_DOWN else "UP"
    print(event_name)
     
btn1 = Button(button_pin=30, pull_mode=Button.PULL_DOWN)
btn2 = Button(button_pin=31, pull_mode=Button.PULL_DOWN)
#btn1.callback.append(demo)
#btn1.irq_open()
#btn1.irq_close()

try:
    while True:        
        if btn1.is_button_on:
            print('button 1 on')
        if btn2.is_button_on:
            print('button 2 on')
        time.sleep(0.1)
except KeyboardInterrupt:
    pass
    #btn1.irq_close()