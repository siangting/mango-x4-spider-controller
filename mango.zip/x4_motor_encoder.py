from machine import Pin
from mango import DCMotor
import time
import math


WHEEL_DIAMETER = 65.0  # mm
GEAR_RATIO = 30.0
ENCODER_LINES = 13.0
TICKS_PER_REV = ENCODER_LINES * 2 * GEAR_RATIO # 雙沿觸發 = 780
WHEEL_CIRCUMFERENCE = WHEEL_DIAMETER * math.pi # 204.2 mm

# 計算每 mm 有多少脈衝
TICKS_PER_MM = TICKS_PER_REV / WHEEL_CIRCUMFERENCE # 約 3.82 Ticks/mm

# --- Motor -----------
m1 = DCMotor(0, 1)
m2 = DCMotor(6, 7)

# --- 編碼器腳位與邏輯 ---
enc_a = Pin(13, Pin.IN, Pin.PULL_UP)
enc_b = Pin(12, Pin.IN, Pin.PULL_UP)

pulse_count = 0

# 編碼器中斷處理函式
def encoder_handler(pin):
    global pulse_count
    # 判斷方向：當 A 改變時，如果 A != B 則是正轉，否則反轉
    if enc_a.value() != enc_b.value():
        pulse_count += 1
    else:
        pulse_count -= 1

# 設定中斷監聽 (雙沿觸發可提高解析度)
enc_a.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=encoder_handler)


def set_motor_speed(speed):
    m1.speed(speed)
    m2.speed(speed)   


def move_distance(target_cm, speed=100):
    global pulse_count
    
    # 轉換單位：cm -> mm -> ticks
    target_ticks = abs(target_cm * 10 * TICKS_PER_MM)
    
    print(f"目標距離: {target_cm} cm, 需要脈衝: {int(target_ticks)}")
    
    pulse_count = 0 # 重置計數
    
    # 開始驅動 (根據正負號決定方向)
    if target_cm > 0:
        set_motor_speed(speed)
    else:
        set_motor_speed(-speed)
        
    # 監測直到脈衝數達標
    while abs(pulse_count) < target_ticks:
        # 這裡可以加入超音波避障或其他邏輯
        time.sleep_ms(1) 
    
    # 抵達目標，主動剎車
    set_motor_speed(0)
    # 建議給一點反向短暫力矩或等待靜止，提升精度
    time.sleep_ms(100)
    
    print(f"抵達！最終脈衝數: {pulse_count}")
    
    
        
 

try:
    move_distance(20)  # 前進 20 cm
    time.sleep(1)
    move_distance(-10) # 後退 10 cm
finally:
    set_motor_speed(0)